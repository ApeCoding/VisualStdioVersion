﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using TodoApi.Models;
using System.Linq;
using Newtonsoft.Json;
using System;
using System.Web;
using System.Runtime.Serialization;

namespace TodoApi.Controllers
{
    [Route("api/[controller]")]
    public class TodoController : Controller
    {
        private readonly TodoContext _context;

        public TodoController(TodoContext context)
        {
            _context = context;

            if (_context.TodoItems.Count() == 0)
            {
                _context.TodoItems.Add(new TodoItem { Name = "Item1" });
                _context.SaveChanges();
            }
        }

         
        [HttpPost]
        [Route("GetAll")]
        public TodoItem GetAll()
        {
            TodoItem GG = new TodoItem();
            GG.IsComplete = false;
            return GG;
            //return _context.TodoItems.ToList();
        }


        [HttpPost("{id}", Name = "GetTodo")]
        public IActionResult GetById(string id)
        {
            var item = _context.TodoItems.FirstOrDefault(t => t.Id == id);
            if (item == null)
            {
                return NotFound();
            }
            return new ObjectResult(item);
        }
    }

}