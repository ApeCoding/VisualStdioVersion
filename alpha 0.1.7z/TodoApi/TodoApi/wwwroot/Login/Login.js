$(document).ready(function() {
    $("#btu").click(function(){
        var username=$("#username").val();
        var password=$("#password").val();

        
        $.post("../Api/Todo/GetAll",
            {"username": username, "password": password},
            function (data) {
                
                if (data.isComplete == true)
                {
                    var kk = "欢迎" + username + ",点击 确定 跳转";
                    alert(kk);
                    window.location.href='index.html';
                }
                else
                {
                    alert("登录失败，请重新登录");
                    window.location.href='Login.html';
                }
            },
            "json"
        )
    })
});

/*

*/